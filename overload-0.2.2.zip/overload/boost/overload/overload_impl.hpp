/*=============================================================================
    Copyright (c) 2007 Marco Cecchetti

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#ifndef _BOOST_OVERLOAD_IMPL_HPP_
#define _BOOST_OVERLOAD_IMPL_HPP_

#include "detail/overload_base.hpp"
#include "detail/trait_by_index.hpp"
#include "detail/trait_by_signature.hpp"
#include "detail/trait_by_functor.hpp"


namespace boost{ namespace overloads{

using detail::extent;
using detail::signature;
using detail::function;
using detail::index;
using detail::has_signature;
using detail::has_functor_signature;


///////////////////////////////////////////////////////////////////////////////
// overload class template

template< 
    typename Sig0, 
    BOOST_PP_ENUM_SHIFTED(BOOST_OVERLOAD_LIMIT, OVL_TEMPL_PARAMS, Sig)
>
//template< typename Sig0, typename Sig1 = no_signature, ... >
class overload
    : public detail::overload_base<0,BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>

{
  public:
    ///////////////////////////////////////////////////////////////////////////
    // type traits
    typedef overload<BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)> this_type;
    typedef 
        detail::overload_base<0,BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>
        base_type;

    // static const unsigned int extent = overloads::extent<this_type>::value;
    static const unsigned int extent;

    template< unsigned int N >
    struct signature
    {
        typedef typename overloads::signature<N, this_type>::type type;
    };

    template< unsigned int N >
    struct function
    {
        typedef typename overloads::function< N, this_type >::type type;
    };

    template< typename Sig >
    struct index
    {
        static const unsigned int value 
            = overloads::index<Sig, this_type>::value;
    };

    template< typename Sig >
    struct has_signature
    {
        static const bool value 
            = overloads::has_signature<Sig, this_type>::value;
    };

    template< typename Functor >
    struct has_functor_signature
    {
        static const bool value 
            = overloads::has_functor_signature<Functor, this_type>::value;
    };

  public:
    overload()
    {
    }

    ///////////////////////////////////////////////////////////////////////////
    // constructors and methods that supports signature deduction
 
    BOOST_PP_REPEAT_FROM_TO(1, BOOST_OVERLOAD_LIMIT, OVL_CTOR, unused)

    BOOST_PP_REPEAT_FROM_TO(1, BOOST_OVERLOAD_LIMIT, OVL_SET, unused)

    ///////////////////////////////////////////////////////////////////////////
    // swap two boost::functions

    template< typename Sig >
    void swap_function( boost::function<Sig>& _f )
    {
        boost::function<Sig>::swap(_f);
    }

    ///////////////////////////////////////////////////////////////////////////
    // signature based methods

    template< typename Sig >
    const boost::function<Sig>& get() const
    {
         return *this;
    }

    template< typename Sig >
    boost::function<Sig>& get()
    {
         return *this;
    }

    template< typename Sig, typename Functor >
    this_type& set( Functor const& _f )
    {
        get<Sig>() = _f;
        return *this;
    }

    template< typename Sig >
    bool empty() const
    {
        return boost::function<Sig>::empty();
    }

    template< typename Sig >
    void clear()
    {
        boost::function<Sig>::clear();
    }

    ///////////////////////////////////////////////////////////////////////////
    // index based methods

    template< unsigned int N >
    const typename function<N>::type& get() const
    {
        return *this;
    }

    template< unsigned int N >
    typename function<N>::type& get()
    {
        return *this;
    }

    template< unsigned int N, typename Functor >
    this_type& set( Functor const& _f )
    {
        get<N>() = _f;
        return *this;
    }

    template< unsigned int N >
    bool empty() const
    {
        return function<N>::type::empty();
    }

    template< unsigned int N >
    void clear()
    {
        function<N>::type::clear();
    }

  private:
    ///////////////////////////////////////////////////////////////////////////
    // function set_impl
    // 

    template< typename Sig >
    void set_impl( boost::function<Sig> const& _f )
    {
        boost::function<Sig>::operator=(_f);
    }

    template< typename Functor >
    void set_impl( 
        Functor const& _f, 
        typename boost::enable_if< has_functor_signature<Functor> >::type* = 0
    )
    {
        typedef
            typename
            detail::base_by_functor<Functor, this_type>::type
            base_type;

        set_impl<Functor, base_type>(_f, *this);
    }

    template< typename Functor, typename Overload >
    void set_impl( Functor const& _f, Overload const& )
    {
        //std::cout << "set_impl" << std::endl;
        typedef
            typename
            detail::base_by_functor<Functor, Overload>::type
            base_type;
        typedef typename Overload::signature_type signature_type;

        set<signature_type>(_f);
        set_impl<Functor, base_type>(_f, *this);
    }

    template< typename Functor, typename Overload>
    void set_impl( Functor const& , 
                   detail::final_overload_base const& )
    {
        //std::cout << "final" << std::endl;
    }

    ///////////////////////////////////////////////////////////////////////////
    // return a pointer to this object casted to the correct base pointer 
    // for a generic functor

    template< typename Functor >
    boost::function<typename detail::signature_by_functor<Functor, this_type>::type>*
    base_ptr( Functor const& )
    {
        return this;
    }

}; // end class overload

// defined out of the class for compatibility with gcc 3.4 and intel 9.1
template< BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, typename Sig) >
const unsigned int 
overload<BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>::extent 
    = overloads::extent< 
          overload<BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)> 
      >::value;

} // end overloads namespace

using overloads::overload;

} // end boost namespace


#endif // _BOOST_OVERLOAD_IMPL_HPP_


