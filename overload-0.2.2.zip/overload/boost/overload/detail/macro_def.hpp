/*=============================================================================
    Copyright (c) 2007 Marco Cecchetti

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#ifndef _BOOST_OVERLOAD_DETAIL_MACRO_DEF_HPP_
#define _BOOST_OVERLOAD_DETAIL_MACRO_DEF_HPP_


#include <boost/preprocessor/repetition.hpp>


#define OVL_DEFAULT_TEMPL_ARG(z, n, unused) \
detail::no_signature
// end macro OVL_DEFAULT_TEMPL_ARG

#define OVL_TEMPL_PARAMS(z, n, T) \
typename BOOST_PP_CAT(T, n) = OVL_DEFAULT_TEMPL_ARG(z, n, unused)
// end macro OVL_TEMPL_PARAMS

#define OVL_SET_IMPL(z,  n,  f) \
set_impl( BOOST_PP_CAT(f, n) );                                                \

// end macro OVL_ASSIGN_TO

#define OVL_SET(z, n, unused) \
template< BOOST_PP_ENUM_PARAMS(n, typename F) >                                \
this_type& set( BOOST_PP_ENUM_BINARY_PARAMS(n, F, const& _f) )                 \
{                                                                              \
    BOOST_PP_REPEAT(n, OVL_SET_IMPL, _f)                                       \
    return *this;                                                              \
}                                                                              \

// end macro OVL_CTOR

#define OVL_CTOR(z, n, unused) \
template< BOOST_PP_ENUM_PARAMS(n, typename F) >                                \
overload( BOOST_PP_ENUM_BINARY_PARAMS(n, F, const& _f) )                       \
{                                                                              \
    set( BOOST_PP_ENUM_PARAMS(n, _f) );                                        \
}                                                                              \

// end macro OVL_CTOR


#endif // _BOOST_OVERLOAD_DETAIL_MACRO_DEF_HPP_

