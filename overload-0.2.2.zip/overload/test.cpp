
#include <iostream>

 

#include <boost/type_traits/is_same.hpp>
#include <boost/static_assert.hpp>
#include <boost/detail/lightweight_test.hpp>


#include "boost/overload/overload.hpp"

#include "test/functors.hpp"


namespace ovld = boost::overloads;
namespace ovdtl = boost::overloads::detail;
using boost::is_same;



#include "test/test_trait_by_index.hpp"
#include "test/test_trait_by_signature.hpp"
#include "test/test_trait_by_functor.hpp"
#include "test/test_signature_deduction.hpp"
#include "test/test_idx_and_sig_methods.hpp"


int main()
{
    test05();
    test06();
    return boost::report_errors();
}

