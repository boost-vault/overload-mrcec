
#include <string>
#include <iostream>
 
#include <boost/detail/lightweight_test.hpp>

//#include "boost_overload_03_01.hpp" // fisrt implementation
#include "boost_overload_04.hpp"  // second implementation


//#define TEST_OVERLOADED_FUNC_OBJ
//#define TEST_POLYMORFIC_FUNC_OBJ

struct foo1_t
{
    int operator() (char )
    {
        return 123;
    }

    int call(char ) 
    {
        return 123;
    }

#ifdef TEST_OVERLOADED_FUNC_OBJ
    char operator()(double )
    {
        return 'x';
    }
#endif

    int x; // function object with a state
};

struct foo2_t
{
    double operator() (int, char) const
    {
        return 123.456;
    }

    double call(int, char ) const
    {
        return 123.456;
    }
};

char foo3(std::string)
{
    return 'x';
}


void foo4(std::string s1, std::string s2, std::string s3)
{
    std::cout << s1 << s2 << s3  << std::endl;
}


struct foo5_t : public foo1_t
{
    int call(char ) 
    {
         return 456;
    }
};

struct  foo6_t
{
    template<typename T> 
    T operator()(T x)
    {
        return x + 1;
    }
};

int main()
{
    typedef int sig1_t (char );
    typedef int sig2_t (foo1_t*, char );
    typedef double sig3_t (int, char );
    typedef double sig4_t (const foo2_t*, int, char );
    typedef char sig5_t (std::string );
    typedef void sig6_t (std::string , std::string , std::string );
    typedef double sig7_t (double );
    typedef int sig8_t (int );
    typedef char sig9_t (double );

    typedef double (foo2_t::* memb_ptr_t) (int, char ) const;

    foo1_t f1;                              // f1  function object
    sig1_t foo1_t::* f2 = &foo1_t::call;    // f2 *member function

    foo2_t f3;                              // f3  function object
    memb_ptr_t f4 = &foo2_t::call;          // f4 *member function
    boost::function<sig5_t> f5(&foo3);      // f5  boost::function
    sig6_t* f6 = &foo4;                     // f6 *free function

#if defined(TEST_OVERLOADED_FUNC_OBJ)
    typedef // append sig9_t to see that it fails with implementation 2 too
         boost::overload<sig1_t, sig2_t, sig3_t, sig4_t, sig5_t, sig6_t>
         overload_type;
#elif defined(TEST_POLYMORFIC_FUNC_OBJ)

    foo6_t f7;                              // f7 polimorfic function object

    typedef // append sig8_t to see that it fails with implementation 2 too
          boost::overload<sig1_t, sig2_t, sig3_t, sig4_t, sig5_t, sig6_t, sig7_t>
          overload_type;
#else
    typedef 
        boost::overload<sig1_t, sig2_t, sig3_t, sig4_t, sig5_t, sig6_t>
        overload_type;
#endif


    overload_type f(f4, f2);  // signature deduction occurs

    f.set(f3, f1); // signature deduction occurs

    f.set<5>(f6);
    f.set<sig5_t>(f5);

    int i = f('x');
    int j =f(&f1, 'x');
    double d = f(123, 'x');
    double e = f(&f3, 123, 'x');
    char c = f("hello");
    f( "Hello",  ", ",  "world !" );

#ifdef TEST_POLYMORFIC_FUNC_OBJ
    f.set(f7);
    double x = f(4.5);
    BOOST_ASSERT(x == 5.5);
#endif

    BOOST_ASSERT(i == 123);
    BOOST_ASSERT(j == 123);
    BOOST_ASSERT(d > 123.455 && d < 123.457);
    BOOST_ASSERT(e > 123.455 && e < 123.457);
    BOOST_ASSERT(c == 'x');

    f.clear<sig6_t>();  // same as f.clear<5>()
    BOOST_ASSERT( f.empty<sig6_t>() ); // same as f.empty<5>()


    boost::function<sig6_t> g(f6);
    f.swap_function(g);
    f("I'm ", "back ", "again !");
    BOOST_ASSERT( g.empty() );

    g = f.get<sig6_t>(); // same as f.get<5>()
    g("That's ", "all ", "folks !");

    return boost::report_errors();

}


