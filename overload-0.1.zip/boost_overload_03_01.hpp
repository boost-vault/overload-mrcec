/*=============================================================================
    Copyright (c) 2007 Marco Cecchetti

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#ifndef _BOOST_OVERLOAD_03_01_
#define _BOOST_OVERLOAD_03_01_


#include <boost/function.hpp>
#include <boost/preprocessor/repetition.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/remove_pointer.hpp>
#include <boost/type_traits/is_base_of.hpp>


#ifndef BOOST_OVERLOAD_LIMIT
    #define BOOST_OVERLOAD_LIMIT 10
#endif


#define OVL_MEMB_FUNC_TRAIT(z, n, unused) \
template< typename ClassT,                                                     \
          typename R BOOST_PP_ENUM_TRAILING_PARAMS(n, typename A) >            \
struct memb_func_trait< R (ClassT::*) ( BOOST_PP_ENUM_PARAMS(n, A) ) >         \
{                                                                              \
    typedef ClassT class_type;                                                 \
    typedef R sig_type( BOOST_PP_ENUM_PARAMS(n, A) );                          \
    typedef R (ClassT::* type) ( BOOST_PP_ENUM_PARAMS(n, A) );                 \
    typedef R (ClassT::* const_type) ( BOOST_PP_ENUM_PARAMS(n, A) ) const;     \
    typedef R binded_type( ClassT* BOOST_PP_ENUM_TRAILING_PARAMS(n, A) );      \
    typedef                                                                    \
        R const_binded_type(const ClassT* BOOST_PP_ENUM_TRAILING_PARAMS(n,A) );\
};                                                                             \
                                                                               \
template< typename ClassT,                                                     \
          typename R BOOST_PP_ENUM_TRAILING_PARAMS(n, typename A) >            \
struct memb_func_trait< R (ClassT::*) ( BOOST_PP_ENUM_PARAMS(n, A) ) const >   \
    : memb_func_trait< R (ClassT::*) ( BOOST_PP_ENUM_PARAMS(n, A) ) >          \
{                                                                              \
};                                                                             \

// end macro OVL_MEMB_FUNC_TRAIT

#define OVL_DEFAULT_TEMPL_ARG(z, n, unused) \
detail::no_signature
// end macro OVL_DEFAULT_TEMPL_ARG

#define OVL_TEMPL_PARAMS(z, n, T) \
typename BOOST_PP_CAT(T, n) = OVL_DEFAULT_TEMPL_ARG(z, n, unused)
// end macro OVL_TEMPL_PARAMS


///////////////////////////////////////////////////////////////////////////////
// if metafunction

template< bool C, typename T, typename E  >
struct if_c
{
    typedef T type;
};

template<typename T, typename E >
struct if_c<false, T, E>
{
    typedef E type;
};

template< typename C, typename T, typename E  >
struct if_ : if_c<C::value, T, E >
{
};
///////////////////////////////////////////////////////////////////////////////

namespace boost
{
namespace detail
{
///////////////////////////////////////////////////////////////////////////////
// member function traits

template< typename MemberPtr>
struct memb_func_trait
{};

BOOST_PP_REPEAT( BOOST_OVERLOAD_LIMIT, OVL_MEMB_FUNC_TRAIT, unused)

///////////////////////////////////////////////////////////////////////////////
// stop recursion structs

struct no_signature {};

struct final_overload_function
{
    typedef final_overload_function base_type;
    static const unsigned int index = -1;
    typedef no_signature signature_type;
    struct final;
    void operator()(final*) const {}
};

///////////////////////////////////////////////////////////////////////////////
// overload_base class

template< 
    unsigned int N,
    typename Sig0, 
    BOOST_PP_ENUM_SHIFTED(BOOST_OVERLOAD_LIMIT, OVL_TEMPL_PARAMS, Sig)
>
struct overload_base
    : public boost::function<Sig0>
    , public overload_base<N+1, BOOST_PP_ENUM_SHIFTED_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>
{
    static const unsigned int index = N;

    typedef Sig0                        signature_type;
    typedef boost::function<Sig0>       function_type;
    typedef 
        overload_base<N+1, BOOST_PP_ENUM_SHIFTED_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)> 
        base_type;

    using function_type::operator();
    using base_type::operator();
};

template< unsigned int N>
struct overload_base<N, BOOST_PP_ENUM(BOOST_OVERLOAD_LIMIT, OVL_DEFAULT_TEMPL_ARG, unused)>
    : public final_overload_function
{
    typedef final_overload_function base_type;
};

} // end namespace detail

///////////////////////////////////////////////////////////////////////////////
// it provides the N-th overload_signature for an overload type

template< unsigned int N, typename Overload, 
          bool FOUND = (N == Overload::base_type::index) >
struct overload_signature
{
  private:
    typedef typename Overload::base_type base;
  public:
    typedef typename overload_signature<N, base>::type type;
};

template< unsigned int N, typename Overload >
struct overload_signature<N, Overload, true>
{
    typedef typename Overload::base_type::signature_type type;
};


#define OVL_SET_IMPL(z,  n,  f) \
set_impl( BOOST_PP_CAT(f, n) );                                                \

// end macro OVL_ASSIGN_TO

#define OVL_SET(z, n, unused) \
template< BOOST_PP_ENUM_PARAMS(n, typename F) >                                \
this_type& set( BOOST_PP_ENUM_BINARY_PARAMS(n, F, const& _f) )                 \
{                                                                              \
    BOOST_PP_REPEAT(n, OVL_SET_IMPL, _f)                                       \
    return *this;                                                              \
}                                                                              \

// end macro OVL_CTOR

#define OVL_CTOR(z, n, unused) \
template< BOOST_PP_ENUM_PARAMS(n, typename F) >                                \
overload( BOOST_PP_ENUM_BINARY_PARAMS(n, F, const& _f) )                       \
{                                                                              \
    set( BOOST_PP_ENUM_PARAMS(n, _f) );                                        \
}                                                                              \

// end macro OVL_CTOR

///////////////////////////////////////////////////////////////////////////////
// overload class template

template< 
    typename Sig0, 
    BOOST_PP_ENUM_SHIFTED(BOOST_OVERLOAD_LIMIT, OVL_TEMPL_PARAMS, Sig)
>
//template< typename Sig0, typename Sig1 = no_signature, ... >
class overload
    : public detail::overload_base<0, BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>
{

  public:
    typedef overload<BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)> this_type;
    typedef 
        detail::overload_base<0, BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>
        base_type;

    template< unsigned int N >
    struct signature
    {
        typedef typename boost::overload_signature<N, this_type>::type type;
    };

    template< unsigned int N >
    struct function
    {
        typedef boost::function< typename signature<N>::type > type;
    };

    template< typename Sig >
    struct has_signature
    {
        static const bool value 
            = is_base_of<boost::function<Sig>, this_type>::value;
    };

    overload()
    {
    }

    BOOST_PP_REPEAT_FROM_TO(1, BOOST_OVERLOAD_LIMIT, OVL_CTOR, unused)

    BOOST_PP_REPEAT_FROM_TO(1, BOOST_OVERLOAD_LIMIT, OVL_SET, unused)

    template< typename Sig >
    void swap_function( boost::function<Sig>& _f )
    {
        boost::function<Sig>::swap(_f);
    }

    ///////////////////////////////////////////////////////////////////////////
    // signature based methods

    template< typename Sig >
    const boost::function<Sig>& get() const
    {
         return *this;
    }

    template< typename Sig >
    boost::function<Sig>& get()
    {
         return *this;
    }

    template< typename Sig, typename Functor >
    this_type& set( Functor const& _f )
    {
        get<Sig>() = _f;
        return *this;
    }

    template< typename Sig >
    bool empty() const
    {
        return boost::function<Sig>::empty();
    }

    template< typename Sig >
    void clear()
    {
        boost::function<Sig>::clear();
    }

    ///////////////////////////////////////////////////////////////////////////
    // index based methods

    template< unsigned int N >
    const typename function<N>::type& get() const
    {
        return *this;
    }

    template< unsigned int N >
    typename function<N>::type& get()
    {
        return *this;
    }

    template< unsigned int N, typename Functor >
    this_type& set( Functor const& _f )
    {
        get<N>() = _f;
        return *this;
    }

    template< unsigned int N >
    bool empty() const
    {
        return function<N>::type::empty();
    }

    template< unsigned int N >
    void clear()
    {
        function<N>::type::clear();
    }

  private:
    ///////////////////////////////////////////////////////////////////////////
    // function set_impl

    template< typename Sig >
    void set_impl( boost::function<Sig> const& _f )
    {
        boost::function<Sig>::operator=(_f);
    }

    template< typename Functor >
    void set_impl( Functor const& _f ) // tag dispatcher
    {
        typedef typename detail::function::get_function_tag<Functor>::type tag;
        set_impl( _f, tag() );
    }

    template< typename Functor >
    void set_impl( Functor _f, detail::function::function_ptr_tag )
    {
        base_ptr_func_ptr(_f)->operator=(_f);
    }

    template< typename Functor >
    void set_impl( Functor _f, detail::function::member_ptr_tag )
    {
        base_ptr_memb_ptr(_f)->operator=(_f);
    }

    template< typename Functor >
    void set_impl( Functor const& _f, detail::function::function_obj_tag )
    {
        base_ptr_func_obj( _f, &Functor::operator() )->operator=(_f);
    }

    template< typename Functor >
    void set_impl( reference_wrapper<Functor> const& _f,  
                   detail::function::function_obj_ref_tag )
    {
        base_ptr_func_obj_ref( _f, &Functor::operator() )->operator=(_f);
    }

    ///////////////////////////////////////////////////////////////////////////
    // helper functions for converting
    // the this pointer to the correct base pointer
   
    // return a pointer to this object for function pointer
    template<typename FunctionPtr>
    boost::function<typename remove_pointer<FunctionPtr>::type>*
    base_ptr_func_ptr( FunctionPtr _f )
    {
        std::cout << "get function_ptr" << std::endl;
        return this;
    }

    // return a pointer to this object for function member pointer
    template<typename MemberPtr>
    boost::function< 
        typename if_<has_signature<typename detail::memb_func_trait<MemberPtr>::binded_type>,
                     typename detail::memb_func_trait<MemberPtr>::binded_type,
                     typename detail::memb_func_trait<MemberPtr>::const_binded_type
        >::type
    >*
    base_ptr_memb_ptr( MemberPtr _f )
    {
        std::cout << "get member function" << std::endl;
        return this;
    }

    // return a pointer to this object for function object
    template< typename FunctionObj, typename MemberPtr>
    boost::function<typename detail::memb_func_trait<MemberPtr>::sig_type>*
    base_ptr_func_obj( FunctionObj const& , MemberPtr )
    {
        std::cout << "get function object" << std::endl;
        return this;
    }

    // return a pointer to this object for function object reference
    template< typename FunctionObj, typename MemberPtr >
    boost::function<typename detail::memb_func_trait<MemberPtr>::sig_type>*
    base_ptr_func_obj_ref( reference_wrapper<FunctionObj> const& _f, MemberPtr )
    {
        std::cout << "get function object ref" << std::endl;
        return this;
    }

}; // end class overload

} // end boost namespace


// cleanup macro defs
#undef OVL_CTOR
#undef OVL_SET
#undef OVL_SET_IMPL
#undef OVL_TEMPL_PARAMS
#undef OVL_DEFAULT_TEMPL_ARG
#undef OVL_MEMB_FUNC_TRAIT


#endif // _BOOST_OVERLOAD_03_01_

