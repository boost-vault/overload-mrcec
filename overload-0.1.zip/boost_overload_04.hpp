/*=============================================================================
    Copyright (c) 2007 Marco Cecchetti

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

#ifndef _BOOST_OVERLOAD_04_
#define _BOOST_OVERLOAD_04_


#include <boost/function.hpp>
#include <boost/preprocessor/repetition.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/remove_pointer.hpp>
#include <boost/type_traits/is_base_of.hpp>


#ifndef BOOST_OVERLOAD_LIMIT
    #define BOOST_OVERLOAD_LIMIT 10
#endif


#define OVL_MEMB_FUNC_TRAIT(z, n, unused) \
template< typename ClassT,                                                     \
          typename R BOOST_PP_ENUM_TRAILING_PARAMS(n, typename A) >            \
struct memb_func_trait< R (ClassT::*) ( BOOST_PP_ENUM_PARAMS(n, A) ) >         \
{                                                                              \
    typedef ClassT class_type;                                                 \
    typedef R sig_type( BOOST_PP_ENUM_PARAMS(n, A) );                          \
    typedef R (ClassT::* type) ( BOOST_PP_ENUM_PARAMS(n, A) );                 \
    typedef R (ClassT::* const_type) ( BOOST_PP_ENUM_PARAMS(n, A) ) const;     \
    typedef R binded_type( ClassT* BOOST_PP_ENUM_TRAILING_PARAMS(n, A) );      \
    typedef                                                                    \
        R const_binded_type(const ClassT* BOOST_PP_ENUM_TRAILING_PARAMS(n,A) );\
};                                                                             \
                                                                               \
template< typename ClassT,                                                     \
          typename R BOOST_PP_ENUM_TRAILING_PARAMS(n, typename A) >            \
struct memb_func_trait< R (ClassT::*) ( BOOST_PP_ENUM_PARAMS(n, A) ) const >   \
    : memb_func_trait< R (ClassT::*) ( BOOST_PP_ENUM_PARAMS(n, A) ) >          \
{                                                                              \
};                                                                             \

// end macro OVL_MEMB_FUNC_TRAIT

#define OVL_DEFAULT_TEMPL_ARG(z, n, unused) \
detail::no_signature
// end macro OVL_DEFAULT_TEMPL_ARG

#define OVL_TEMPL_PARAMS(z, n, T) \
typename BOOST_PP_CAT(T, n) = OVL_DEFAULT_TEMPL_ARG(z, n, unused)
// end macro OVL_TEMPL_PARAMS


namespace boost
{
namespace detail
{
///////////////////////////////////////////////////////////////////////////////
// if metafunction

template< bool C, typename T, typename E  >
struct if_c
{
    typedef T type;
};

template<typename T, typename E >
struct if_c<false, T, E>
{
    typedef E type;
};

template< typename C, typename T, typename E  >
struct if_ : if_c<C::value, T, E >
{
};

///////////////////////////////////////////////////////////////////////////////
// member function traits

template< typename MemberPtr>
struct memb_func_trait
{};

BOOST_PP_REPEAT(BOOST_OVERLOAD_LIMIT, OVL_MEMB_FUNC_TRAIT, unused)

///////////////////////////////////////////////////////////////////////////////
// stop recursion structs

struct no_signature {};

struct final_overload_function
{
    typedef final_overload_function base_type;
    static const unsigned int index = -1;
    typedef no_signature signature_type;
    struct final;
    void operator()(final*) const {}
};

///////////////////////////////////////////////////////////////////////////////
// utility to test if a function object has a specific signature

template<typename MemberPtr > struct func_obj_has_signature_impl;

template< typename FunctionObj, typename Sig>
struct func_obj_has_signature_impl< Sig FunctionObj::* >
{ 
  private:
    template<Sig FunctionObj::*> struct helper;
    template<typename T> static char check(helper<&T::operator()>* ); 
    template<typename T> static char (& check(...))[2]; 
  public: 
    static const bool value = ( sizeof(check<FunctionObj>(0)) == sizeof(char) );
};

struct member_func_const_tag {}; // for member functions of kind "R f(..) const"

template<typename FunctionObj, typename Sig, typename const_tag = void > 
struct func_obj_has_signature
{ 
    static const bool value = func_obj_has_signature_impl<Sig FunctionObj::*>::value;
}; 

template<typename FunctionObj, typename Sig >
struct func_obj_has_signature<FunctionObj, Sig, member_func_const_tag>
{
    private:
      typedef typename memb_func_trait<Sig FunctionObj::*>::const_type 
              const_memb_func_ptr;
    public: 
      static const bool value = func_obj_has_signature_impl<const_memb_func_ptr>::value;
};

template<typename FunctionObj>
struct func_obj_has_signature<FunctionObj, no_signature, member_func_const_tag>
{
    static const bool value = false;
};

///////////////////////////////////////////////////////////////////////////////
// utility to discover if a function object has a signature compatible 
// with an overload type and, in case, get the matching signature

template<typename FunctionObj, typename Overload,
         bool FOUND 
            = func_obj_has_signature<
                    FunctionObj, 
                    typename Overload::base_type::signature_type
            >::value 
            || func_obj_has_signature<
                    FunctionObj,
                    typename Overload::base_type::signature_type,
                    member_func_const_tag
            >::value
>
struct get_func_obj_match
{
  private:
    typedef typename Overload::base_type base;
  public:
    typedef typename get_func_obj_match<FunctionObj, base>::type type;
};

template<typename FunctionObj, typename Overload>
struct get_func_obj_match<FunctionObj, Overload, true>
{
    typedef typename Overload::base_type type;
};

template<typename FunctionObj, bool FOUND>
struct get_func_obj_match<FunctionObj, final_overload_function, FOUND>
{
    typedef final_overload_function type;
};


template< typename T>
struct failed_signature_deduction_due_to_overloaded_or_polymorfic_function_object_of_type;

template<typename FunctionObj, typename Overload>
struct get_func_obj_signature
{
    typedef 
        typename get_func_obj_match<FunctionObj, Overload>::type 
        first_match;
    typedef 
        typename get_func_obj_match<FunctionObj, first_match>::type 
        second_match;
    typedef 
        typename 
        if_< boost::is_same<second_match, final_overload_function>,
             typename first_match::signature_type,
             failed_signature_deduction_due_to_overloaded_or_polymorfic_function_object_of_type<FunctionObj>
        >::type
        type;   
};

///////////////////////////////////////////////////////////////////////////////
// utility to discover if a generic functor has a signature compatible 
// with an overload type and, in case, get the matching signature

template< typename Sig, typename Overload >
struct has_signature
{
    static const bool value 
        = boost::is_base_of<boost::function<Sig>, Overload>::value;
};

template< typename Functor, 
          typename Overload,
          typename function_tag 
                = typename detail::function::get_function_tag<Functor>::type
>
struct find_signature{ typedef no_signature type; };

template< typename FunctionPtr, typename Overload>
struct find_signature<FunctionPtr, Overload, function::function_ptr_tag>
{
  private:
    typedef typename remove_pointer<FunctionPtr>::type func_ptr_t;
  public:
    typedef 
        typename if_< has_signature<func_ptr_t, Overload>
                    , func_ptr_t, no_signature >::type
        type;
};

template< typename MemberPtr, typename Overload>
struct find_signature<MemberPtr, Overload, function::member_ptr_tag>
{
  private:
    typedef 
        typename memb_func_trait<MemberPtr>::binded_type
        binded_type;
    typedef 
        typename memb_func_trait<MemberPtr>::const_binded_type
        const_binded_type;
  public:
    typedef 
        typename if_< has_signature<binded_type, Overload>
                    , binded_type
                    , typename if_< has_signature<const_binded_type, Overload>
                                  , const_binded_type, no_signature >::type
                    >::type
        type;
};

template< typename FunctionObj, typename Overload>
struct find_signature<FunctionObj, Overload, function::function_obj_tag>
{
    typedef typename get_func_obj_signature<FunctionObj, Overload>::type type;
};

template< typename FunctionObj, typename Overload>
struct find_signature<boost::reference_wrapper<FunctionObj>, Overload, 
                     function::function_obj_ref_tag>
{
    typedef typename get_func_obj_signature<FunctionObj, Overload>::type type;
};

///////////////////////////////////////////////////////////////////////////////
// overload_base class

template< 
    unsigned int N,
    typename Sig0, 
    BOOST_PP_ENUM_SHIFTED(BOOST_OVERLOAD_LIMIT, OVL_TEMPL_PARAMS, Sig)
>
struct overload_base
    : public boost::function<Sig0>
    , public overload_base<N+1, BOOST_PP_ENUM_SHIFTED_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>
{
    static const unsigned int index = N;

    typedef Sig0                        signature_type;
    typedef boost::function<Sig0>       function_type;
    typedef 
        overload_base<N+1, BOOST_PP_ENUM_SHIFTED_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)> 
        base_type;

    using function_type::operator();
    using base_type::operator();
};

template< unsigned int N>
struct overload_base<N, BOOST_PP_ENUM(BOOST_OVERLOAD_LIMIT, OVL_DEFAULT_TEMPL_ARG, unused)>
    : public final_overload_function
{
    typedef final_overload_function base_type;
};


} // end namespace detail

///////////////////////////////////////////////////////////////////////////////
// it provides the N-th overload_signature for an overload type

template< unsigned int N, typename Overload, 
          bool FOUND = (N == Overload::base_type::index) >
struct overload_signature
{
  private:
    typedef typename Overload::base_type base;
  public:
    typedef typename overload_signature<N, base>::type type;
};

template< unsigned int N, typename Overload >
struct overload_signature<N, Overload, true>
{
    typedef typename Overload::base_type::signature_type type;
};


#define OVL_SET_IMPL(z,  n,  f) \
set_impl( BOOST_PP_CAT(f, n) );                                                \

// end macro OVL_ASSIGN_TO

#define OVL_SET(z, n, unused) \
template< BOOST_PP_ENUM_PARAMS(n, typename F) >                                \
this_type& set( BOOST_PP_ENUM_BINARY_PARAMS(n, F, const& _f) )                 \
{                                                                              \
    BOOST_PP_REPEAT(n, OVL_SET_IMPL, _f)                                       \
    return *this;                                                              \
}                                                                              \

// end macro OVL_CTOR

#define OVL_CTOR(z, n, unused) \
template< BOOST_PP_ENUM_PARAMS(n, typename F) >                                \
overload( BOOST_PP_ENUM_BINARY_PARAMS(n, F, const& _f) )                       \
{                                                                              \
    set( BOOST_PP_ENUM_PARAMS(n, _f) );                                        \
}                                                                              \

// end macro OVL_CTOR

///////////////////////////////////////////////////////////////////////////////
// overload class template

template< 
    typename Sig0, 
    BOOST_PP_ENUM_SHIFTED(BOOST_OVERLOAD_LIMIT, OVL_TEMPL_PARAMS, Sig)
>
//template< typename Sig0, typename Sig1 = no_signature, ... >
class overload
    : public detail::overload_base<0,BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>

{

  public:
    typedef overload<BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)> this_type;
    typedef 
        detail::overload_base<0,BOOST_PP_ENUM_PARAMS(BOOST_OVERLOAD_LIMIT, Sig)>
        base_type;

    template< unsigned int N >
    struct signature
    {
        typedef typename boost::overload_signature<N, this_type>::type type;
    };

    template< unsigned int N >
    struct function
    {
        typedef boost::function< typename signature<N>::type > type;
    };

    template< typename Sig >
    struct has_signature
    {
        static const bool value 
            = detail::has_signature<Sig, this_type>::value;
    };

    template< typename Functor >
    struct find_signature
    {
        typedef typename detail::find_signature<Functor, this_type>::type type;
    };

    overload()
    {
    }

    BOOST_PP_REPEAT_FROM_TO(1, BOOST_OVERLOAD_LIMIT, OVL_CTOR, unused)

    BOOST_PP_REPEAT_FROM_TO(1, BOOST_OVERLOAD_LIMIT, OVL_SET, unused)

    template< typename Sig >
    void swap_function( boost::function<Sig>& _f )
    {
        boost::function<Sig>::swap(_f);
    }

    ///////////////////////////////////////////////////////////////////////////
    // signature based methods

    template< typename Sig >
    const boost::function<Sig>& get() const
    {
         return *this;
    }

    template< typename Sig >
    boost::function<Sig>& get()
    {
         return *this;
    }

    template< typename Sig, typename Functor >
    this_type& set( Functor const& _f )
    {
        get<Sig>() = _f;
        return *this;
    }

    template< typename Sig >
    bool empty() const
    {
        return boost::function<Sig>::empty();
    }

    template< typename Sig >
    void clear()
    {
        boost::function<Sig>::clear();
    }

    ///////////////////////////////////////////////////////////////////////////
    // index based methods

    template< unsigned int N >
    const typename function<N>::type& get() const
    {
        return *this;
    }

    template< unsigned int N >
    typename function<N>::type& get()
    {
        return *this;
    }

    template< unsigned int N, typename Functor >
    this_type& set( Functor const& _f )
    {
        get<N>() = _f;
        return *this;
    }

    template< unsigned int N >
    bool empty() const
    {
        return function<N>::type::empty();
    }

    template< unsigned int N >
    void clear()
    {
        function<N>::type::clear();
    }

  private:
    ///////////////////////////////////////////////////////////////////////////
    // function set_impl

    template< typename Sig >
    void set_impl( boost::function<Sig> const& _f )
    {
        boost::function<Sig>::operator=(_f);
    }

    template< typename Functor >
    void set_impl( Functor const& _f )
    {
        typedef typename find_signature<Functor>::type sig_t;
        boost::function<sig_t>::operator=(_f);
    }

    ///////////////////////////////////////////////////////////////////////////
    // return a pointer to this object casted to the correct base pointer 
    // for a generic functor

    template< typename Functor >
    boost::function<typename find_signature<Functor>::type>*
    base_ptr( Functor const& )
    {
        return this;
    }

}; // end class overload

} // end boost namespace


// cleanup macro defs
#undef OVL_CTOR
#undef OVL_SET
#undef OVL_SET_IMPL
#undef OVL_TEMPL_PARAMS
#undef OVL_DEFAULT_TEMPL_ARG
#undef OVL_MEMB_FUNC_TRAIT


#endif // _BOOST_OVERLOAD_04_


